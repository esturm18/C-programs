/* Name: Emma R Sturm
 * Class: CSE360
 * Date: 09/04/2024 at 5:35pm
 * Professor: Ben McCamish
 * Assignment 1: The purpose of this project is to create a hashtable that can also self-evaluate and grow when need be while reading word pairs in from a file(s). 
 * */
#include <string.h>
#include <assert.h>
#include <ctype.h>
#include "getWord.h"
#include<stdio.h>
#include<stdlib.h>
#include "struct.h"
#include "crc64.h"

#define CRC64_REV_POLY      0x95AC9329AC4BC9B5ULL
#define CRC64_INITIALIZER   0xFFFFFFFFFFFFFFFFULL
#define CRC64_TABLE_SIZE    256
#define loadFactor  1
#define growthFactor  3

//INSERT function: Inserts nodes into a linked list for a bucket
void insert(Node *first, char *wordPair, int occurences){
	Node *temp=searchfromfront(first, wordPair);//Temp node is returned by search if the wordpair already exists in the table. 
	if (temp!=NULL){//If the wordpair does exist, increment the number of occurences it has and free the wordpair 
		++temp->occurences;
		free(wordPair);
	        return; 	
	} 	
	Node *newnode; //Otherwise if temp returned NULL, create a newnode that stores the new wordPair.
	newnode=malloc(sizeof(Node));

	//input wordpair into new node
	newnode->data = malloc(strlen(wordPair)+1);  
	strcpy(newnode->data, wordPair); 

	//Insert 1 into occurences
	newnode->occurences=occurences;	//Occurences passed will be either 1 for a new node or a random number if rehashing (wordpair might have an occurence associated with it when inserting into a new hashtable). 

	//insert newnode into linked list
	newnode->next=first->next;
	first->next=newnode; 	
	
	//Free the wordpair
	free(wordPair);
	}


//SEARCH function: this function will return a node if the wordpair is already found. This node is the node associated with the wordpair. 
Node *search(HashTable *hashtable, char *wordPair){
	unsigned long long index= crc64(wordPair) % hashtable->bucketCount; 
	Node *first= hashtable->buckets[index]; 
        //traverse through linked list searching for matching wordPair
	Node *current = first->next; 
	while(current!= NULL){
                if (strcmp((char *) current->data, wordPair)==0){//Compare the wordpair with the value stored in the node (current->data).
			return current; //Return if valid
               	}	
		current=current->next; 
		}
		return NULL; //Word pair was not found 
	}

//SEARCHFROMFRONT function: this function is basically the same thing as the search function but just accepts the first node to a linked list instead of the table. I could have rewritten the two search functions together but ran out of time. 
Node *searchfromfront(Node *first, char *wordPair){
        //traverse through linked list searching for matching wordPair
	Node *current = first->next; 
	while(current!= NULL){
                if (strcmp((char *) current->data, wordPair)==0){
			return current; 
               	}	
		current=current->next; 
		}
		return NULL; //Word pair was not found 
	}

//FREELIST function: frees the linkedlist associated with a bucket in the hashtable
void freelist(Node *first){
       Node *temp=first->next;
       Node *prev=first; 

	//Node *temp=first
	while(temp!=NULL){
		free(prev->data); 
		free(prev);
		prev=temp;

		temp=temp->next;
        }

	//free the last node
	free(prev->data);
	free(prev); 
}

//PRINT function: Prints out the linked lists
void print(Node *first){ 
        Node *temp=first->next;
        while(temp!=NULL){
                printf("%10d %s\n", temp->occurences,(char *) temp->data);
                temp=temp->next;
        }
}


