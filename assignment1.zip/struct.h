/* Name: Emma R Sturm
 * Class: CSE360
 * Date: 09/04/2024 at 5:35pm
 * Professor: Ben McCamish
 * Assignment 1: The purpose of this project is to create a hashtable that can also self-evaluate and grow when need be while reading word pairs in from a file(s). 
 * */

//Structure for linked list nodes. Each node holds the values data (a.k.a wordpair), occurences (the number of times that a wordpair occurs), and a pointer to the next node. 
typedef struct Node{
	void *data;
	int occurences; 
	struct Node *next; 

}Node; 

//Structure for the hashtable. Holds an array of pointers to the linked lists (buckets) and the bucketcount
typedef struct{
	Node **buckets; //array of pointers to linked lists
	int numOfElements; 
	int bucketCount;//bucket total count. Could have also initialized as type size_t 
	int hashtimeflag; 
}HashTable; 

//Linked list function prototypes:
char* getNextWord(FILE* fd);  
void cleanUp(char *word); //Clean up function gets rid of characters that are not in the alphabet 
char *squishTheWords(char *previousWord, char *currentWord);
Node *newN(char *wordPair, int occurences);
Node *init();
void insert(Node *first, char *wordPair, int occurences);
void print(Node *first);
void freelist(Node *first); 
Node *search(HashTable *table, char *wordPair);
Node *searchfromfront(Node *first, char *wordPair);


//Hash function prototypes:
unsigned long long crc64(char* string); 
void printhash(HashTable *hashtable); 
void inserthash(HashTable *table, char *wordPair, int occurences);
HashTable *inithash(int size);
void freehash(HashTable *table);
Node **hashToArray(HashTable *table, int *length);
int compare(const void *a, const void *b);
void resizeHashTable(HashTable *table, int new_size);
void makehash(HashTable *hashtable, FILE *fp);


