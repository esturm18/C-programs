/* Name: Emma R Sturm
 * Class: CSE360
 * Date: 09/04/2024 at 5:35pm
 * Professor: Ben McCamish
 * Assignment 1: The purpose of this project is to create a hashtable that can also self-evaluate and grow when need be while reading word pairs in from a file(s). 
 * */
#include <string.h>
#include <assert.h>
#include <ctype.h>
#include "getWord.h"
#include<stdio.h>
#include<stdlib.h>
#include "struct.h"
#include "crc64.h"

#define CRC64_REV_POLY      0x95AC9329AC4BC9B5ULL
#define CRC64_INITIALIZER   0xFFFFFFFFFFFFFFFFULL
#define CRC64_TABLE_SIZE    256
#define loadFactor  1
#define growthFactor  3

//MAIN FUNCTION: The main function will process the file input and will also process the the user's command from the command line argurment. 
int main(int argc, char *argv[]){
	int argCount=0;
	int index =1; 


	char message1[] = "Usage: ./pairsofwords <-count> fileName1 <fileName2>...\n\n"; //Messages if user does not enter in the correct format
	char message2[] = "Where: count is the number of words to display\n\n"; 


	//Command line checking	
        if (argc < 2){ //If command line argument is less than 2, print out an error message. 
		fprintf(stderr, "Error: no fileName arguments specified.\n\n");
		printf("%9s%s"," ", message1);
		printf("%9s%s"," ", message2);
		return 1;	
        }else{ //Otherwise, if the command line argument is 
	       int status = sscanf(argv[1], "-%d", &argCount);//Check to see if the second argument starts with a - then number. If successful, status will be
//	       printf("status = %d\n", status); 
	       if (status==1){//If the status result is 1, that means sscanf was successfully and the second argument is a - followed by an integer
			index=2;
			if (argCount == 0){
				fprintf(stderr, "Error: Illegal line count argument '%s'\n\n", argv[1]);
				printf("%9s%s"," ", message1);
				printf("%9s%s"," ", message2);
				return 1; 
			}
			if (argc == 2){
				fprintf(stderr, "Error: no fileName arguments specified.\n\n");
				printf("%9s%s"," ", message1);
				printf("%9s%s"," ", message2);
				return 1;	
			}
	       }
		 if ((!isdigit(argv[1][1])) && (argv[1][0]== '-')){
			fprintf(stderr, "Error: Illegal line count argument '%s'\n\n", argv[1]);
			printf("%9s%s"," ", message1);
			printf("%9s%s"," ", message2);
			return 1; 
		}				
	}	


        //If it has trouble reading any file at all...! Check, exit program
        for (int i=index; i<argc; i++){
                FILE *fp = fopen(argv[i], "r");
                        if (fp==NULL){
                        	fprintf(stderr, "Error: Cannot read file '%s'\n", argv[i]); 
				return 1;
                
			}
                fclose(fp);
        }



	//End of command line reading
        
	//Initialize the hashtable:inithash will create a hashtable with a starting size of 256. 
	HashTable *hashtable = inithash(256); 

	//Reread files again and input their information into the makehash function
        for (int i=index; i<argc; i++){
                FILE *fp=fopen(argv[i], "r");
                if (fp==NULL){
                        fprintf(stderr, "Error opening up this file\n");
                        return 1;
                }

		makehash(hashtable,fp); //makehash will start creating the hash
		fclose(fp); 
	}
	int length =0; 
        Node **info = hashToArray(hashtable, &length);//Initialize an array of linked lists to send through the qsort function

        qsort(info, length, sizeof(Node *), compare); //Qsort will print out the array info in order of occurences.
	if (index == 2){ //If the index is 2,the user entered in a "-" followed by a number.
		if (argCount > length){ //if the number the user entered is greater than the number of wordpairs in a file, simply just print out all the wordpairs. 
			argCount=length;
		}else{ //If the index is 1, then set the length to what the user specified.  
			length=argCount;
		}
	}
	//Adjusted length goes into the for loop
        for (int i=0; i<length; i++){ //Print out the sorted array of word pairs and occurences.
                printf("%10d %s\n", info[i]->occurences, (char *)info[i]->data);
        }  

//	printhash(hashtable); Used for testing purposes. 
 	
        free(info); //Free the array
        freehash(hashtable); //Free the table
  	return 0;
}


