/* Name: Emma R Sturm
 * Class: CSE360
 * Date: 09/04/2024 at 5:35pm
 * Professor: Ben McCamish
 * Assignment 1: The purpose of this project is to create a hashtable that can also self-evaluate and grow when need be while reading word pairs in from a file(s). 
 * */
#include <string.h>
#include <assert.h>
#include <ctype.h>
#include "getWord.h"
#include<stdio.h>
#include<stdlib.h>
#include "struct.h"
#include "crc64.h"

#define CRC64_REV_POLY      0x95AC9329AC4BC9B5ULL
#define CRC64_INITIALIZER   0xFFFFFFFFFFFFFFFFULL
#define CRC64_TABLE_SIZE    256
#define loadFactor  1
#define growthFactor  3

//SQUISHTHEWORDS function: concatenates the previous word and current word returned by the getNextWord function (getWord.c) to form a wordpair
char *squishTheWords(char *previousWord, char *currentWord){
        int length=strlen(previousWord) + strlen(currentWord)+2;
        char *wordPair= malloc(length*sizeof(char)); //allocate memory for the wordpair
        strcpy(wordPair, previousWord);
        strcat(wordPair, " ");
        strcat(wordPair, currentWord);
        return wordPair;
}

//GETNEXTWORD function: Code for the function "getNextWord" is from the assignment handout for "getWord.c" I just renamed it. 
char* getNextWord(FILE* fd) {
        char ch;
        char wordBuffer[DICT_MAX_WORD_LEN];
        int putChar = 0;

        assert(fd != NULL);

        while ((ch = fgetc(fd)) != EOF) {
                if (isalpha(ch)) break;
        }
        if (ch == EOF) return NULL;
        wordBuffer[putChar++] = tolower(ch);

        while ((ch = fgetc(fd)) != EOF) {
                if (isspace(ch) || putChar >= DICT_MAX_WORD_LEN - 1) break;
                if (isalnum(ch)) {
                        wordBuffer[putChar++] = tolower(ch);
                }
        }
        wordBuffer[putChar] = '\0';
	char *result = strdup(wordBuffer);
	if (result==NULL){
		fprintf(stderr, "Memory allocation failed in getNextWord\n"); 
	}
        return result;
}

//COMPARE function: compares the occurence values of wordpairs to print them out in descending order. Qsort call is in the main function (pairsofwords.c)
int compare(const void *a, const void *b){
        Node *previous = *(Node **)a;
        Node *current = *(Node **)b;
        return current->occurences - previous->occurences;
} 

