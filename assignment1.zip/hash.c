/* Name: Emma R Sturm
 * Class: CSE360
 * Date: 09/04/2024 at 5:35pm
 * Professor: Ben McCamish
 * Assignment 1: The purpose of this project is to create a hashtable that can also self-evaluate and grow when need be while reading word pairs in from a file(s). 
 * */
#include <string.h>
#include <assert.h>
#include <ctype.h>
#include "getWord.h"
#include<stdio.h>
#include<stdlib.h>
#include "struct.h"
#include "crc64.h"

#define CRC64_REV_POLY      0x95AC9329AC4BC9B5ULL
#define CRC64_INITIALIZER   0xFFFFFFFFFFFFFFFFULL
#define CRC64_TABLE_SIZE    256
#define loadFactor  1
#define growthFactor  3


//CRC64 Function: code for "crc64" derived from the assignment handout. This function is the hash function that I use to calculate the index/buckets of where to store the wordpairs.  
unsigned long long crc64(char* string) {
    if (string == NULL){
	    fprintf(stderr, "Error: Null string passed to crc64\n");
	    return 0; 
    }
    static int initFlag = 0;
    static unsigned long long table[CRC64_TABLE_SIZE];

    if (!initFlag) { initFlag++;
        for (int i = 0; i < CRC64_TABLE_SIZE; i++) {
            unsigned long long part = i;
            for (int j = 0; j < 8; j++) {
                if (part & 1)
                    part = (part >> 1) ^ CRC64_REV_POLY;
                else part >>= 1;
            }
            table[i] = part;
        }
    }

    unsigned long long crc = CRC64_INITIALIZER;
    while (*string)
        crc = table[(crc ^ *string++) & 0xff] ^ (crc >> 8);
    return crc;
}

//RESIZEHASHTABLE Function: rehashes the hashtable by completing making a new one and then freeing the other one. 
void resizeHashTable(HashTable *table, int size){
	HashTable *newTable = inithash(size); //Create a new hashtable

	//Transferring the old table into the new one
	for (int i=0; i<table->bucketCount; i++){
		Node *first=table->buckets[i];
		Node *current = first->next; 
		while(current!=NULL){
			if (current->data!=NULL){
				insert(newTable->buckets[crc64(current->data) % newTable->bucketCount], current->data, current->occurences);
			}
			current=current->next; 
		}
	}	

	//Free the old buckets
	for (int i=0; i<table->bucketCount; i++){
		Node *current = table->buckets[i];
		while (current!=NULL){
			Node *temp = current;
			current = current->next;
			free(temp); 
		}	
	}
	

	free(table->buckets);//free all the buckets!
	table->buckets = newTable->buckets;//set the current table to be equal to the new table
	table->bucketCount = newTable->bucketCount; 
	free(newTable); //free the new table
}

//MAKEHASH Function: This function reads the wordpairs form the file and inserts them into the hashtable. 
void makehash(HashTable *hashtable, FILE *fp){ char
	*previousWord=getNextWord(fp); //Use getNextWord to get the nextword in the file
	assert(previousWord!=NULL);

	char *currentWord; 

	//get the wordPair here!
	while ((currentWord=getNextWord(fp))!=NULL){
		char *wordPair = squishTheWords(previousWord, currentWord);
		 
		Node *foundNode = search(hashtable, wordPair);//Search to see if the wordpair has already been stored in the table 
		if (foundNode !=NULL){
			if (foundNode->occurences >=1){ //If the number of occurences is already greater than or equal to 1, that means that that wordPair already exists, so increment it.
				inserthash(hashtable, wordPair, foundNode->occurences+1);
			        free(wordPair); //Free the wordpair
			}else{
				foundNode->occurences++;//Otherwise just simply increment it
				free(wordPair); //Free the wordpair
			}
		}else{
			
			//If node is not found, create a new node by passing it into the inserthash function with an occurence of 1.
			inserthash(hashtable,wordPair, 1);
		
		}
		free(previousWord);
		previousWord=currentWord;
	}
		free(previousWord); //free the last word pair
	
}

//INITHASH Function: initializes the hash table
HashTable *inithash(int size){ 
	HashTable *table=malloc(sizeof(HashTable));
        assert(table!=NULL);

	table->buckets = malloc(size *sizeof(Node*));
	table->numOfElements = 0; 	
	table->hashtimeflag=0; 
	assert(table->buckets!=NULL); 

	table->bucketCount = size;
        for(int i=0; i<size; i++){ //Create the sentinel nodes for the new hashtable
		Node *temp; 
		temp=malloc(sizeof(Node));
		temp->data=NULL;
		temp->occurences=0;
		temp->next=NULL;

		//Insert the node into the hashtable
		table->buckets[i]=temp; 
        }
        return(table);
}


//INSERTHASH Function: insert nodes into the hashtable, also processes when a rehash needs to be done.
void inserthash(HashTable *hashtable, char *wordPair, int occurences){
        int currentBuckets= hashtable->bucketCount;
        float outcome = hashtable->numOfElements/currentBuckets; //Calculate load 

       	if (outcome >= loadFactor){ //Number of Elements divided by the current number of Buckets. If this is greater than the loadFactor of 1, it will trigger a rehash.
		int newSize = currentBuckets* growthFactor; //new size of the hashtable
	 	resizeHashTable(hashtable,newSize);//Will insert info form old data and store it in the new one and also create a new size
        }

	unsigned long long index = crc64(wordPair) % hashtable->bucketCount;//Calculate the index for where the wordpair is going to be stored in the hash table.  

	if (index < hashtable->bucketCount){//If the index is less than the bucketCount. Added this if statement just in case one of the sentinels gets indexed (index number will be large if a sentinel passes through). 
	if (hashtable->buckets[index]==NULL){//If the index is null, create a sentinel node there.
		hashtable->buckets[index]=malloc(sizeof(Node));
		hashtable->buckets[index]->data=NULL;
		hashtable->buckets[index]->next =NULL;
		hashtable->buckets[index]->occurences=0;
		}	
	
		Node *foundNode =search(hashtable, wordPair); //Search the hashtable to make sure that the wordpair doesn't already exist. 
		if (foundNode!=NULL){ //If it is not found, the occurences will remain the same as they were passed into this function.
			foundNode->occurences = occurences;
		}else{//Otherwise, increment the number of elements in the hashtable and insert the wordpair into a linked list. 
			hashtable->numOfElements++; 
			insert(hashtable->buckets[index], wordPair, occurences); //insert function for linked list in list.c
		}	
	}
}

//FREEHASH function: Frees the whole hash table by freeing each linked list at a time. Linked lists are free in the freelist function located in list.c
void freehash(HashTable *table){
        for (int i=0; i<table->bucketCount; i++){
	       	freelist(table->buckets[i]);
	}
        free(table->buckets);
        free(table);
}

//PRINTHASH function: Prints out the hash. Print function located in list.c
void printhash(HashTable *table){
	for(int i=0; i<table->bucketCount; i++){
		print(table->buckets[i]); 
	}
}


//HASHTOARRAY function: Returns an array of the hashtable to the main function.
Node **hashToArray(HashTable *hashtable, int *length){
	*length = hashtable->numOfElements;
	Node **info = malloc((*length)*sizeof(Node*));
        if (info==NULL){
                fprintf(stderr, "Memory allocation failed\n");
                return NULL;
        }

	int index=0;
	for(int i=0; i<hashtable->bucketCount; i++){//Traverse through the hashtable
		Node *current = hashtable->buckets[i];
		current= current->next;
		while (current!=NULL){
				info[index]=current;
			        index++; 	
			current=current->next;
		}

	}
	*length = index; //Length of the array
	return info; 
}
