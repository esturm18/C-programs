Name:Emma R Sturm
Date: 09/04/2024
Professor: Professor McCamish
Project: Assignment1 : Implementating a hash table to read in pairs of words from a file.

To compile my code: type in "make" and it will compile all my files. Here are different ways you can interact with the command line:

You can enter :
	./pairsofwords filename, filename, filename,...

OR:
	./pairsofwords -count filename, filename, filename,...

Important Note: I am turning this in late. I did submit my program earlier today but was still having trouble with my rehash function. However, I have now gotten it working and would like to turn this one in despite the fact that I will lose points for turning it in late. This is the version I am the most proud of and am happy that the regrow function is working properly. 

To create this program, I initially created linked lists and then after getting those working, layered the hashtable on top of it. So, in my program you will see some functions that are similar, i.e. inserthash and insert.

Thank you for reading,
Emma Sturm
